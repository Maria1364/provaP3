/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int main()

 //Mostrar média de aluno
 
 //entrada de dados
   
    Console.Writeline("Digite a primeira nota":
    nota1=Convert.ToDouble(Console.ReadLine());
    
    Console.Writeline("Digite a segunda nota":
    nota2=Convert.ToDouble(Console.ReadLine());
    
    Console.Writeline("Digite a terceira nota"
    nota3=Convert.ToDouble(Console.ReadLine());
   
    Console.Writeline("Digite a quarta nota")
    nota4=Convert.ToDouble(Console.ReadLine());
    
 //calcular a média 
 
    media = ( nota1 + nota2 + nota3 + nota4 ) / 4;

   if(media >=7.0)
    
    
    media = ( nota1 + nota2 + nota3 + nota4 ) / 4;

   if(media >=7.0)
 
   {
     Console.Writeline("Aluno Aprovado");
   }
   else
   {
     Console.WriteLine("Aluno Reprovado");
   }

   Console.ReadKey();
   }
 }
 